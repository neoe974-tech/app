const Database = require('better-sqlite3')
const path = require('path')
const dbPath = process.env.DB_PATH || path.join(process.cwd(),'data','musicstream.db')
const db = new Database(dbPath)
db.exec(`
CREATE TABLE IF NOT EXISTS artists (id TEXT PRIMARY KEY, name TEXT, genre TEXT, streams INTEGER, earnings REAL);
CREATE TABLE IF NOT EXISTS tokens (id INTEGER PRIMARY KEY, access_token TEXT, refresh_token TEXT, scope TEXT, expires_in INTEGER, obtained_at INTEGER);
`)
const artists = [
  ['1','Luna Wave','Ambient',425123,2875.5],
  ['2','Solar Drift','Electronica',321231,2143.0],
  ['3','Neon Harbor','Synthwave',212312,1419.75],
  ['4','Velvet Circuit','Chillhop',112312,749.25]
]
const insert = db.prepare('INSERT OR REPLACE INTO artists (id,name,genre,streams,earnings) VALUES (?,?,?,?,?)')
artists.forEach(a=>insert.run(...a))
console.log('DB initialized at', dbPath)
db.close()
