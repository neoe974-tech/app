import fetch from 'node-fetch'
import Database from 'better-sqlite3'
import path from 'path'

const DB_PATH = process.env.DB_PATH || path.join(process.cwd(),'data','musicstream.db')

function getDb(){
  const db = new Database(DB_PATH)
  db.exec(`CREATE TABLE IF NOT EXISTS tokens (id INTEGER PRIMARY KEY, access_token TEXT, refresh_token TEXT, scope TEXT, expires_in INTEGER, obtained_at INTEGER)`)
  return db
}

export default async function handler(req,res){
  try {
    const db = getDb()
    const row = db.prepare('SELECT * FROM tokens ORDER BY id DESC LIMIT 1').get()
    if (!row) return res.status(404).json({ error: 'no token stored' })
    const r = await fetch('https://api.spotify.com/v1/me', { headers: { Authorization: 'Bearer ' + row.access_token } })
    const j = await r.json()
    res.status(r.status).json(j)
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'failed to fetch' })
  }
}
