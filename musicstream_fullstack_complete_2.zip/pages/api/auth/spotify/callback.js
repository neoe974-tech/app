import fetch from 'node-fetch'
import Database from 'better-sqlite3'
import path from 'path'

const DB_PATH = process.env.DB_PATH || path.join(process.cwd(),'data','musicstream.db')

function getDb(){
  const db = new Database(DB_PATH)
  db.exec(`CREATE TABLE IF NOT EXISTS tokens (id INTEGER PRIMARY KEY, access_token TEXT, refresh_token TEXT, scope TEXT, expires_in INTEGER, obtained_at INTEGER)`)
  return db
}

export default async function handler(req,res){
  const { code, state } = req.query
  const clientId = process.env.SPOTIFY_CLIENT_ID || 'YOUR_SPOTIFY_CLIENT_ID'
  const clientSecret = process.env.SPOTIFY_CLIENT_SECRET || 'YOUR_SPOTIFY_CLIENT_SECRET'
  const redirectUri = process.env.SPOTIFY_REDIRECT_URI || 'http://localhost:3000/api/auth/spotify/callback'

  if (!code) return res.status(400).send('Missing code')

  const body = new URLSearchParams({
    grant_type: 'authorization_code',
    code,
    redirect_uri: redirectUri,
    client_id: clientId,
    client_secret: clientSecret
  })

  const tokenRes = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString()
  })
  const tokenJson = await tokenRes.json()

  // store tokens in SQLite (server-side)
  try {
    const db = getDb()
    const stmt = db.prepare('INSERT INTO tokens (access_token, refresh_token, scope, expires_in, obtained_at) VALUES (?, ?, ?, ?, ?)')
    stmt.run(tokenJson.access_token, tokenJson.refresh_token, tokenJson.scope || '', tokenJson.expires_in || 0, Date.now())
    db.close()
  } catch (e) {
    console.error('DB store failed', e)
  }

  // For demo, redirect to admin with a success message (in prod, use secure cookies + sessions)
  res.redirect('/admin?auth=success')
}
