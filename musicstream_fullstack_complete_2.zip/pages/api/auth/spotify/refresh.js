import fetch from 'node-fetch'
import Database from 'better-sqlite3'
import path from 'path'

const DB_PATH = process.env.DB_PATH || path.join(process.cwd(),'data','musicstream.db')

function getDb(){
  const db = new Database(DB_PATH)
  db.exec(`CREATE TABLE IF NOT EXISTS tokens (id INTEGER PRIMARY KEY, access_token TEXT, refresh_token TEXT, scope TEXT, expires_in INTEGER, obtained_at INTEGER)`)
  return db
}

export default async function handler(req,res){
  try {
    const db = getDb()
    const row = db.prepare('SELECT * FROM tokens ORDER BY id DESC LIMIT 1').get()
    if (!row) return res.status(404).json({ error: 'no token stored' })
    const clientId = process.env.SPOTIFY_CLIENT_ID || 'YOUR_SPOTIFY_CLIENT_ID'
    const clientSecret = process.env.SPOTIFY_CLIENT_SECRET || 'YOUR_SPOTIFY_CLIENT_SECRET'
    const body = new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: row.refresh_token,
      client_id: clientId,
      client_secret: clientSecret
    })
    const tokenRes = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString()
    })
    const tokenJson = await tokenRes.json()
    // update DB with new access token and expiry
    const stmt = db.prepare('UPDATE tokens SET access_token = ?, expires_in = ?, obtained_at = ? WHERE id = ?')
    stmt.run(tokenJson.access_token, tokenJson.expires_in || 0, Date.now(), row.id)
    db.close()
    res.status(200).json({ token: tokenJson })
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'refresh failed' })
  }
}
