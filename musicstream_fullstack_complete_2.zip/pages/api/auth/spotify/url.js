import { serialize } from 'cookie'

export default function handler(req,res){
  const clientId = process.env.SPOTIFY_CLIENT_ID || 'YOUR_SPOTIFY_CLIENT_ID'
  const redirectUri = process.env.SPOTIFY_REDIRECT_URI || 'http://localhost:3000/api/auth/spotify/callback'
  const scopes = [
    'user-read-email',
    'playlist-read-private',
    'user-library-read',
    'user-read-private'
  ]
  const state = Math.random().toString(36).substring(2,15)
  res.setHeader('Set-Cookie', serialize('spotify_auth_state', state, { path:'/', httpOnly:true }))
  const url = 'https://accounts.spotify.com/authorize' +
    '?response_type=code' +
    '&client_id=' + encodeURIComponent(clientId) +
    '&scope=' + encodeURIComponent(scopes.join(' ')) +
    '&redirect_uri=' + encodeURIComponent(redirectUri) +
    '&state=' + encodeURIComponent(state)
  res.status(200).json({ url })
}
