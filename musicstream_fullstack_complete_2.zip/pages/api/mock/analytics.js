export default function handler(req,res){
  const labels = Array.from({length:30}, (_,i)=>{
    const d=new Date(); d.setDate(d.getDate()-(29-i)); return d.toISOString().slice(5,10);
  });
  const values = Array.from({length:30}, ()=> Math.floor(2000 + Math.random()*8000));
  const topTracks = [
    { title: 'Midnight Echoes', streams: 124523, earnings: 842.10 },
    { title: 'Aurora Drift', streams: 98231, earnings: 662.00 },
    { title: 'Neon Pulse', streams: 75421, earnings: 523.44 },
    { title: 'Quiet Machines', streams: 65412, earnings: 453.20 },
    { title: 'Harmonic Field', streams: 50120, earnings: 321.80 }
  ];
  const artists = [
    { id: '1', name: 'Luna Wave', genre:'Ambient', streams: 425123, earnings: 2875.50, change: '+5.4%' },
    { id: '2', name: 'Solar Drift', genre:'Electronica', streams: 321231, earnings: 2143.00, change: '+2.1%' },
    { id: '3', name: 'Neon Harbor', genre:'Synthwave', streams: 212312, earnings: 1419.75, change: '-1.2%' },
    { id: '4', name: 'Velvet Circuit', genre:'Chillhop', streams: 112312, earnings: 749.25, change: '+8.9%' }
  ];
  res.status(200).json({
    summary: { totalStreams: 1245234, totalEarnings: 8420.50, activeListeners: 45231 },
    streamsOverTime: { labels, values },
    topTracks,
    artists
  })
}
