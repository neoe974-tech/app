import path from 'path'
import fs from 'fs'

export default function handler(req,res){
  // For prototype, we return mocked artists. In production, read from DB.
  const artists = [
    { id: '1', name: 'Luna Wave', genre:'Ambient', streams: 425123 },
    { id: '2', name: 'Solar Drift', genre:'Electronica', streams: 321231 },
    { id: '3', name: 'Neon Harbor', genre:'Synthwave', streams: 212312 },
    { id: '4', name: 'Velvet Circuit', genre:'Chillhop', streams: 112312 }
  ]
  res.status(200).json({ artists })
}
