export default function handler(req,res){
  const { id } = req.query
  // Mocked response per artist id
  const artist = { id, name: id==='1' ? 'Luna Wave' : id==='2' ? 'Solar Drift' : id==='3' ? 'Neon Harbor' : 'Velvet Circuit', genre: id==='3' ? 'Synthwave' : 'Ambient' }
  const labels = Array.from({length:30}, (_,i)=>{ const d=new Date(); d.setDate(d.getDate()-(29-i)); return d.toISOString().slice(5,10); })
  const values = Array.from({length:30}, ()=> Math.floor(1000 + Math.random()*6000))
  const topTracks = [
    { title: 'Track A', streams: Math.floor(50000+Math.random()*80000) },
    { title: 'Track B', streams: Math.floor(20000+Math.random()*50000) },
    { title: 'Track C', streams: Math.floor(10000+Math.random()*40000) }
  ]
  res.status(200).json({ artist, streamsOverTime:{labels,values}, topTracks })
}
