import Database from 'better-sqlite3'
import path from 'path'

const DB_PATH = process.env.DB_PATH || path.join(process.cwd(),'data','musicstream.db')

export default function handler(req,res){
  try {
    const db = new Database(DB_PATH)
    const rows = db.prepare('SELECT * FROM artists').all()
    db.close()
    if (rows.length) return res.status(200).json({ artists: rows })
  } catch (e) {
    // fallback to mocked
  }
  res.status(200).json({ artists: [
    { id:'1', name:'Luna Wave', genre:'Ambient', streams:425123 },
    { id:'2', name:'Solar Drift', genre:'Electronica', streams:321231 }
  ] })
}
