import useSWR from 'swr'
import Link from 'next/link'

const fetcher = (url)=>fetch(url).then(r=>r.json())

export default function Artists() {
  const { data } = useSWR('/api/artists', fetcher, { refreshInterval: 0 })

  if (!data) return <div className="container py-8">Loading...</div>

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-4">Artists</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {data.artists.map(a=>(
          <Link key={a.id} href={`/artists/${a.id}`}><a className="card p-4 block">
            <div className="flex justify-between items-center">
              <div><h3 className="font-semibold">{a.name}</h3><div className="text-sm text-gray-400">{a.genre}</div></div>
              <div className="text-green-400 font-bold">{a.streams.toLocaleString()}</div>
            </div>
          </a></Link>
        ))}
      </div>
    </div>
  )
}
