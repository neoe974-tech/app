import { useRouter } from 'next/router'
import useSWR from 'swr'
import Chart from 'chart.js/auto'
import { useEffect, useRef } from 'react'

const fetcher = (url)=>fetch(url).then(r=>r.json())

export default function ArtistPage() {
  const router = useRouter()
  const { id } = router.query
  const { data } = useSWR(id ? `/api/artists/${id}` : null, fetcher)
  const chartRef = useRef(null)

  useEffect(()=>{
    if (data && chartRef.current) {
      const ctx = chartRef.current.getContext('2d')
      new Chart(ctx, { type:'line', data:{ labels: data.streamsOverTime.labels, datasets:[{data:data.streamsOverTime.values, borderColor:'rgba(99,102,241,0.9)', backgroundColor:'rgba(99,102,241,0.08)', fill:true}] }, options:{ responsive:true, maintainAspectRatio:false } })
    }
  },[data])

  if (!data) return <div className="container py-8">Loading...</div>

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-2">{data.artist.name}</h1>
      <div className="text-sm text-gray-400 mb-6">{data.artist.genre}</div>

      <section className="card mb-6" style={{height:320}}>
        <h3 className="font-semibold mb-2">Streams Over Time</h3>
        <canvas ref={chartRef} style={{width:'100%',height:'240px'}}></canvas>
      </section>

      <section className="card">
        <h3 className="font-semibold mb-2">Top Tracks</h3>
        <ul className="mt-2 space-y-2">
          {data.topTracks.map(t=>(<li key={t.title} className="flex justify-between"><div>{t.title}</div><div className="text-gray-300">{t.streams.toLocaleString()} streams</div></li>))}
        </ul>
      </section>
    </div>
  )
}
