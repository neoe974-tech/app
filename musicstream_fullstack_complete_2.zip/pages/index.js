import Link from 'next/link'
export default function Home() {
  return (
    <div className="min-h-screen">
      <header className="bg-gray-900 border-b border-gray-800 p-6">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-md bg-gradient-to-r from-green-600 to-blue-600 flex items-center justify-center font-bold">MS</div>
            <h1 className="text-2xl font-bold">MusicStream</h1>
          </div>
          <nav className="space-x-6 hidden md:flex">
            <Link href="/"><a className="text-gray-300 hover:text-white">Home</a></Link>
            <Link href="/admin"><a className="text-gray-300 hover:text-white">Admin Dashboard</a></Link>
          </nav>
        </div>
      </header>

      <main className="container py-12">
        <section className="bg-gradient-to-r from-green-600 to-blue-600 p-12 rounded-xl text-center">
          <h2 className="text-4xl font-bold mb-4">Fair Music Streaming for Everyone</h2>
          <p className="mb-6 text-gray-100">Discover amazing music while supporting artists with industry-leading royalty rates.</p>
          <div className="flex justify-center gap-4">
            <a className="bg-white text-black px-6 py-3 rounded-full font-semibold" href="/account/signup">Get Started Free</a>
            <a className="border border-white px-6 py-3 rounded-full" href="/music">Browse Music</a>
          </div>
        </section>
      </main>
    </div>
  )
}
