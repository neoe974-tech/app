import { useEffect, useRef, useState } from 'react'
import Chart from 'chart.js/auto'
import axios from 'axios'
import Link from 'next/link'

export default function Admin() {
  const [summary, setSummary] = useState({ totalStreams: '—', totalEarnings: '—', activeListeners: '—' })
  const streamsRef = useRef(null)
  const tracksRef = useRef(null)

  useEffect(() => {
    axios.get('/api/mock/analytics').then(res => {
      const data = res.data
      setSummary(data.summary)
      const ctx = streamsRef.current.getContext('2d')
      new Chart(ctx, {
        type: 'line',
        data: { labels: data.streamsOverTime.labels, datasets: [{ label: 'Streams', data: data.streamsOverTime.values, fill:true, backgroundColor:'rgba(34,197,94,0.08)', borderColor:'rgba(34,197,94,0.9)', tension:0.35, pointRadius:0 }] },
        options: { responsive:true, maintainAspectRatio:false }
      })
      const ctx2 = tracksRef.current.getContext('2d')
      new Chart(ctx2, {
        type: 'bar',
        data: { labels: data.topTracks.map(t=>t.title), datasets:[{data:data.topTracks.map(t=>t.streams)}] },
        options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false }
      })
    })
  },[])

  const startSpotifyAuth = async () => {
    const res = await axios.get('/api/auth/spotify/url')
    window.location.href = res.data.url
  }

  return (
    <div className="min-h-screen">
      <header className="bg-gray-900 border-b border-gray-800 p-6">
        <div className="container flex items-center justify-between">
          <h1 className="text-2xl font-bold">MusicStream Admin</h1>
          <div className="flex gap-4 items-center">
            <Link href="/"><a className="text-gray-300">Home</a></Link>
            <button onClick={startSpotifyAuth} className="bg-green-500 text-black px-4 py-2 rounded font-semibold">Connect Spotify</button>
          </div>
        </div>
      </header>

      <main className="container py-8 space-y-6">
        <section className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Dashboard</h2>
          <Link href="/artists"><a className="text-green-400">View Artists →</a></Link>
        </section>

        <section className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="card">
            <div className="text-sm text-gray-400">Total Streams (30d)</div>
            <div className="text-3xl font-bold mt-2">{summary.totalStreams}</div>
          </div>
          <div className="card">
            <div className="text-sm text-gray-400">Total Earnings (30d)</div>
            <div className="text-3xl font-bold mt-2">{summary.totalEarnings}</div>
          </div>
          <div className="card">
            <div className="text-sm text-gray-400">Active Listeners (30d)</div>
            <div className="text-3xl font-bold mt-2">{summary.activeListeners}</div>
          </div>
        </section>

        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="card" style={{height:320}}>
            <h2 className="font-semibold text-xl mb-3">Streams Over Time</h2>
            <canvas ref={streamsRef} style={{width:'100%',height:'240px'}}></canvas>
          </div>
          <div className="card" style={{height:320}}>
            <h2 className="font-semibold text-xl mb-3">Top Tracks</h2>
            <canvas ref={tracksRef} style={{width:'100%',height:'240px'}}></canvas>
          </div>
        </section>
      </main>
    </div>
  )
}
